<?php  
$servername="Localhost";
$database="webmuza_feisto";
$dussername="root";
$dpassword="";
$domain="https://";
$conn= mysqli_connect($servername,$dussername,$dpassword,$database);
if (!$conn) {
	die("connection_error");
}
?>