<?php  
function mobile_validate($data){
$data=array('status'=>false);
return $data;
}
?>