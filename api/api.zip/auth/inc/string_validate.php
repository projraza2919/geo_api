<?php  
function string_validate($data){

return $data;
}

?>