<?php  
include 'inc/header.php';
include 'inc/db.php';
include 'inc/string_validate.php';
$name=string_validate($data['name']);
$email=string_validate($data['email']);
$userid=string_validate($data['userid']);
$device=string_validate($data['device']);
$key=bin2hex(random_bytes(16));
$haskey=password_hash($key, PASSWORD_DEFAULT);
$sql="SELECT * FROM users WHERE email='$email' AND del=0  ORDER BY id DESC LIMIT 1";
if (mysqli_query($conn,$sql)) {
	$run=mysqli_query($conn,$sql);
	if (mysqli_num_rows($run)>0) {
		while ($fetch=mysqli_fetch_assoc($run)) {
			if ($fetch['status']=='active') {
				$response=array('status'=>false,'msg'=>'This email is taken, Contact Admin');
			}else{
				$response=array('status'=>false,'msg'=>'Your account status is '.$fetch['status']);
			}
		}			
	}else{
		$temp="INSERT INTO users(name,email,userid,passkey,device,status) VALUES('$name','$email','$userid','$key','$device','under verification')";
		if (mysqli_query($conn,$temp)) {
			if (send_via_email($email,$name,$key,$domain)) {
				$response=array('status'=>true);
			}
			
		}
	}
}

include 'inc/footer.php';

?>