<?php  
include 'inc/header.php';
include 'inc/db.php';
include 'inc/string_validate.php';

$email=string_validate($data['email']);
$device=string_validate($data['device']);

$sql="SELECT * FROM users WHERE email='$email' AND device='$device' AND del=0  ORDER BY id DESC LIMIT 1";
if (mysqli_query($conn,$sql)) {
	$run=mysqli_query($conn,$sql);
	if (mysqli_num_rows($run)>0) {
		while ($fetch=mysqli_fetch_assoc($run)) {
			if ($fetch['status']=='active') {
				$response=array('status'=>true);
			}else{
				$response=array('status'=>false,'msg'=>'Your account status is '.$fetch['status']);
			}
		}			
	}
}
//$response=array('status'=>true,'key'=>'shjd545sdsds54');
include 'inc/footer.php';

?>