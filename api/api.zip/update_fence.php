<?php  
include 'inc/header.php';
include 'inc/db.php';
include 'inc/string_validate.php';

$email=string_validate($data['email']);
$fence=string_validate($data['fence']);
$location=array();
$bool=0;
if ($fence=='i') {
	$bool=1;
}
$sql="UPDATE users SET fence=$bool WHERE email='$email'";
if (mysqli_query($conn,$sql)) {
	$response=array('status'=>true);
}
include 'inc/footer.php';

?>